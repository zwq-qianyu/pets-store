//处理box点击效果的js程序  开始
//获取旗舰精品区的小图img对象
var list = document.getElementById("box-color-list1").getElementsByTagName("img"); 
//遍历图片并添加鼠标移入事件
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic1").src = this.src;
  };
}

var list = document.getElementById("box-color-list2").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic2").src = this.src;
  };
}

var list = document.getElementById("box-color-list3").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic3").src = this.src;
  };
}

/*
//获取热卖宠物区的小图img对象
var list = document.getElementById("box-color-list01").getElementsByTagName("img"); 
//遍历图片并添加鼠标移入事件
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic01").src = this.src;
  };
}
var list = document.getElementById("box-color-list02").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic02").src = this.src;
  };
}*/
var list = document.getElementById("box-color-list03").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic03").src = this.src;
  };
}
var list = document.getElementById("box-color-list04").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic04").src = this.src;
  };
}
var list = document.getElementById("box-color-list05").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic05").src = this.src;
  };
}
var list = document.getElementById("box-color-list06").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic06").src = this.src;
  };
}
var list = document.getElementById("box-color-list07").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic07").src = this.src;
  };
}
var list = document.getElementById("box-color-list08").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic08").src = this.src;
  };
}

//获取配件精选区的小图img对象
var list = document.getElementById("box-color-list001").getElementsByTagName("img"); 
//遍历图片并添加鼠标移入事件
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic001").src = this.src;
  };
}
var list = document.getElementById("box-color-list002").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic002").src = this.src;
  };
}
var list = document.getElementById("box-color-list003").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic003").src = this.src;
  };
}
var list = document.getElementById("box-color-list004").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic004").src = this.src;
  };
}
var list = document.getElementById("box-color-list005").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic005").src = this.src;
  };
}
var list = document.getElementById("box-color-list006").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic006").src = this.src;
  };
}
var list = document.getElementById("box-color-list007").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic007").src = this.src;
  };
}
var list = document.getElementById("box-color-list008").getElementsByTagName("img"); 
for(var i=0;i<list.length;i++){
  list[i].onclick=function(){
    document.getElementById("box-header-pic008").src = this.src;
  };
}
//处理box点击效果的js程序  结束